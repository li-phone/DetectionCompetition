# GENERATED VERSION FILE
# TIME: Fri May  8 00:33:18 2020

__version__ = '1.0rc1+76ca5b3'
short_version = '1.0rc1'
