from .nms_wrapper import nms, soft_nms

__all__ = ['nms', 'soft_nms']
