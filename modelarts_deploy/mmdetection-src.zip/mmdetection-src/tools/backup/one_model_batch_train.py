from onecla.batch_train import *
# main()
from onecla.batch_train import batch_train_with_garbage_dataset
batch_train_with_garbage_dataset()